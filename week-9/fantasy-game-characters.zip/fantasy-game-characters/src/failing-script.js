// TODO: Implement this script
"use strict";

throw new Error ("This script is to purposely fail");