// TODO: Implement this script
"use strict";

const gameCharacters = [
  {Class: "Warrior", Gender: "Other", Specialty: "Melee combat"},
  {Class: "Mage", Gender: "Female", Specialty:"Ice magic"},
  {Class: "Rogue", Gender: "Male", Specialty:"Stealth"}
];

console.log(JSON.stringify(gameCharacters));